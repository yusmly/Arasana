# ARASANA'yı Yayına Alma Rehberi (Ücretsiz)

Bu klasördeki dosyaları kullanarak ARASANA'yı gerçek bir web adresinde
yayınlayacağız, sonra o adresi Chrome'a arama motoru olarak tanıtacağız.

## 1. Anthropic API anahtarı al

1. https://console.anthropic.com adresine git, hesap oluştur / giriş yap.
2. Sol menüden **API Keys** bölümüne gir.
3. **Create Key** ile yeni bir anahtar oluştur, bir yere kopyala (bir daha
   tam haliyle gösterilmeyecek).
4. Not: Bu API kullanım bazlı ücretlendirilir. Yeni hesaplarda genelde
   küçük bir deneme kredisi bulunur; **Billing** sekmesinden bakiyeni
   kontrol edebilirsin. Bir arama motorunu denemek için gereken maliyet
   çok düşüktür (birkaç kuruş/sorgu seviyesinde).

## 2. GitHub'a yükle

1. https://github.com adresinde ücretsiz hesap oluştur (yoksa).
2. Yeni bir repo oluştur, adı: `arasana`.
3. Bu klasördeki tüm dosyaları (bu dosya hariç fark etmez) o repoya yükle.
   - GitHub'ın web arayüzünden "Add file > Upload files" ile sürükle-bırak
     yapabilirsin, komut satırı bilmene gerek yok.

## 3. Vercel ile yayınla

1. https://vercel.com adresine git, **GitHub hesabınla** giriş yap.
2. **Add New... > Project** de.
3. Az önce yüklediğin `arasana` reposunu seç, **Import** de.
4. Kurulum ekranında **Environment Variables** kısmına şunu ekle:
   - Key: `ANTHROPIC_API_KEY`
   - Value: (1. adımda kopyaladığın anahtar)
5. **Deploy** butonuna bas, 1 dakika içinde bitecek.
6. Deploy bitince sana şuna benzer bir adres verecek:
   `https://arasana-xxxxxxx.vercel.app`
   Bu senin gerçek, canlı ARASANA adresin.

## 4. Chrome'a arama motoru olarak ekle

1. Chrome'da **Ayarlar (Settings)** > **Arama motoru (Search engine)**
   > **Arama motorlarını yönet (Manage search engines)** sayfasına git.
2. **Ekle (Add)** butonuna bas.
3. Şu bilgileri gir:
   - **Ad:** ARASANA
   - **Kısayol:** arasana
   - **URL:** `https://arasana-xxxxxxx.vercel.app/?q=%s`
     (kendi Vercel adresini `%s` ile birlikte yaz)
4. Kaydet.

## 5. Kullan

Chrome adres çubuğuna `arasana` yaz, **Tab**'a bas, sonra sorgunu yaz ve
Enter'a bas. Artık ARASANA senin tarayıcı arama motorun.

---

**Not:** Anthropic API anahtarını asla tarayıcı koduna (index.html içine)
yazma — bu dosyalarda anahtar sadece `api/search.js` üzerinden, Vercel'in
sunucusunda, Environment Variable olarak saklanıyor. Bu sayede kimse
tarayıcıdan senin anahtarını göremez.
